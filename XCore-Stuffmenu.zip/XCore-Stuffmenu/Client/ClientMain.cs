    using System;
    using CitizenFX.Core;
    using CitizenFX.Core.Native;
    using XCore.Client.Appearance;

    namespace XCore.Client
    {
        public class ClientMain : BaseScript
        {
            private static XMenu MainMenu;
            public static Noclip Noclip { get; private set; }
            public ClientMain()
            {
                // Initialize Noclip before any other operation
                Noclip = new Noclip();
                Tick += Noclip.OnTick;

                // Initialize the menu after Noclip to avoid null references
                var mainMenu = new XMenu();

                API.RegisterCommand("toggleMenu", new Action(mainMenu.ToggleMenu), false);
                API.RegisterKeyMapping("toggleMenu", "Toggle Menu", "keyboard", "F5");
                API.RegisterKeyMapping("navigateUp", "Navigate Up", "keyboard", "UP");
                API.RegisterKeyMapping("navigateDown", "Navigate Down", "keyboard", "DOWN");
                API.RegisterKeyMapping("backMenu", "Go Back/Close Menu", "keyboard", "BACK");
                API.RegisterKeyMapping("selectOption", "Select Option", "keyboard", "RETURN");

                // Register key mappings for Noclip controls
                API.RegisterKeyMapping("noclipMoveUp", "Move Up", "keyboard", "W");
                API.RegisterKeyMapping("noclipMoveDown", "Move Down", "keyboard", "S");
                API.RegisterKeyMapping("noclipMoveLeft", "Move Left", "keyboard", "A");
                API.RegisterKeyMapping("noclipMoveRight", "Move Right", "keyboard", "D");
                API.RegisterKeyMapping("noclipIncreaseSpeed", "Increase Speed", "keyboard", "SHIFT");
                API.RegisterKeyMapping("noclipDecreaseSpeed", "Decrease Speed", "keyboard", "CONTROL");
                API.RegisterKeyMapping("noclipMoveUp", "Move Up", "keyboard", "Q");
                API.RegisterKeyMapping("noclipMoveDown", "Move Down", "keyboard", "E");
            }
            
            private static void ToggleMenu()
            {
                MainMenu.ToggleMenu();
            }
        }
    }