﻿using System.Threading.Tasks;
using CitizenFX.Core;
using CitizenFX.Core.Native;

namespace XCore.Client.Appearance
{
    public class Noclip
    {
        private bool _noclipActive = false;
        private float _noclipSpeed = 1.0f;

        public async Task OnTick()
        {
            if (_noclipActive)
            {
                HandleNoclipMovement();
            }
            await BaseScript.Delay(0);
        }

        public void ToggleNoclip()
        {
            _noclipActive = !_noclipActive;

            var playerPed = Game.PlayerPed;

            if (_noclipActive)
            {
                API.SetEntityInvincible(playerPed.Handle, true);
                API.SetEntityVisible(playerPed.Handle, false, false);
                API.SetEntityCollision(playerPed.Handle, false, false);
                API.FreezeEntityPosition(playerPed.Handle, false); // Ensure the player is not frozen
            }
            else
            {
                API.SetEntityInvincible(playerPed.Handle, false);
                API.SetEntityVisible(playerPed.Handle, true, false);
                API.SetEntityCollision(playerPed.Handle, true, true);
                API.FreezeEntityPosition(playerPed.Handle, false);
            }
        }

        private void HandleNoclipMovement()
        {
            var playerPed = Game.PlayerPed;
            var forwardVector = Vector3.Zero;
            var rightVector = Vector3.Zero;
            var upVector = Vector3.Zero;
            var position = Vector3.Zero;

            // Fetch entity forward, right, and up vectors
            API.GetEntityMatrix(playerPed.Handle, ref forwardVector, ref rightVector, ref upVector, ref position);

            // Control input
            float moveX = 0.0f, moveY = 0.0f, moveZ = 0.0f;

            if (API.IsControlPressed(0, (int)Control.MoveUpOnly)) // W key
            {
                moveY += 1.0f;
            }
            if (API.IsControlPressed(0, (int)Control.MoveDownOnly)) // S key
            {
                moveY -= 1.0f;
            }
            if (API.IsControlPressed(0, (int)Control.MoveLeftOnly)) // A key
            {
                moveX -= 1.0f;
            }
            if (API.IsControlPressed(0, (int)Control.MoveRightOnly)) // D key
            {
                moveX += 1.0f;
            }
            if (API.IsControlPressed(0, 44)) // Q key (Up)
            {
                moveZ += 1.0f;
            }
            if (API.IsControlPressed(0, 38)) // E key (Down)
            {
                moveZ -= 1.0f;
            }

            // Speed adjustment
            if (API.IsControlPressed(0, (int)Control.Sprint)) // Shift key
            {
                _noclipSpeed = 2.0f;
            }
            else if (API.IsControlPressed(0, (int)Control.Duck)) // Control key
            {
                _noclipSpeed = 0.5f;
            }
            else
            {
                _noclipSpeed = 1.0f;
            }

            // Calculate new position
            Vector3 newPos = playerPed.Position + (forwardVector * moveY * _noclipSpeed) + (rightVector * moveX * _noclipSpeed) + (upVector * moveZ * _noclipSpeed);

            // Set new position
            API.SetEntityCoordsNoOffset(playerPed.Handle, newPos.X, newPos.Y, newPos.Z, true, true, true);
        }
    }
}
