﻿using System;
using System.Collections.Generic;

namespace XCore.Client.Appearance
{
    public class Menu
    {
        public string Title { get; }
        public List<string> Items { get; }
        public Action<int> OnSelect { get; }

        public Menu(string title, List<string> items, Action<int> onSelect)
        {
            Title = title;
            Items = items;
            OnSelect = onSelect;
        }
    }
}