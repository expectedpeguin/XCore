﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using CitizenFX.Core;
using CitizenFX.Core.Native;
using CitizenFX.Core.UI;

namespace XCore.Client.Appearance
{
    public class XMenu : BaseScript
    {
        private readonly Stack<Menu> _menuStack;
        private int _selectedIndex;
        private bool _isMenuOpen;

        public XMenu()
        {
            _menuStack = new Stack<Menu>();
            _selectedIndex = 0;
            _isMenuOpen = false;

            API.RegisterCommand("toggleMenu", new Action(ToggleMenu), false);
            API.RegisterCommand("navigateUp", new Action(NavigateUp), false);
            API.RegisterCommand("navigateDown", new Action(NavigateDown), false);
            API.RegisterCommand("selectOption", new Action(SelectOption), false);
            API.RegisterCommand("backMenu", new Action(BackMenu), false);

            var mainMenu = new Menu("Main Menu", new List<string> { "Option 1", "Option 2", "SubMenu" }, MainMenuSelection);
            _menuStack.Push(mainMenu);
        }

        private void MainMenuSelection(int index)
        {
            if (index == 2)
            {
                var subMenu = new Menu("SubMenu", new List<string> { "Toggle Noclip", "Sub Option 2", "Back" }, SubMenuSelection);
                _menuStack.Push(subMenu);
            }
            else
            {
                Screen.ShowNotification($"Selected {index + 1}");
            }
        }

        private void SubMenuSelection(int index)
        {
            switch (index)
            {
                case 0:
                    if (ClientMain.Noclip != null)
                    {
                        ClientMain.Noclip.ToggleNoclip();
                    }
                    else
                    {
                        Screen.ShowNotification("Noclip is not initialized.");
                    }
                    break;
                case 2: 
                    _menuStack.Pop();
                    break;
                default: 
                    Screen.ShowNotification($"SubMenu Option {index + 1} Selected");
                    break;
            }
        }

        public void ToggleMenu()
        {
            _isMenuOpen = !_isMenuOpen;
            if (_isMenuOpen)
            {
                Tick += DrawMenuTick;
            }
            else
            {
                Tick -= DrawMenuTick;
            }
        }

        private async Task DrawMenuTick()
        {
            if (_isMenuOpen && _menuStack.Count > 0)
            {
                DrawMenu(_menuStack.Peek());
            }
            await Task.FromResult(0);
        }

        private void DrawMenu(Menu menu)
        {
            const float menuX = 0.15f;  // X position closer to the left side
            const float menuY = 0.15f;  // Y position closer to the top
            const float menuWidth = 0.25f;  // Smaller width for the menu
            const float menuHeight = 0.25f;  // Smaller height for the menu
            const float itemHeight = 0.04f;  // Adjust item height for smaller menu

            var itemStartY = menuY - (itemHeight * menu.Items.Count) / 2;

            // Draw the background rectangle
            DrawRect(menuX, menuY, menuWidth, menuHeight, 20, 20, 20, 230);

            // Draw the menu title
            DrawText(menu.Title, menuX, menuY - menuHeight / 2 + 0.03f, 0.4f, new[] { 255, 255, 255, 255 }, true);

            // Draw each menu item
            for (var i = 0; i < menu.Items.Count; i++)
            {
                var isSelected = i == _selectedIndex;
                var color = isSelected ? new[] { 255, 255, 255, 255 } : new[] { 180, 180, 180, 255 };
                var itemY = itemStartY + (i * itemHeight);

                if (isSelected)
                {
                    // Highlight the selected item with a background rectangle
                    DrawRect(menuX, itemY + itemHeight / 2, menuWidth - 0.02f, itemHeight, 100, 149, 237, 200);
                }

                // Draw the item text centered horizontally and vertically within the highlight
                DrawText(menu.Items[i], menuX, itemY + (itemHeight / 2) - 0.015f, 0.35f, color, false);
            }
        }



        private static void DrawRect(float x, float y, float width, float height, int r, int g, int b, int a)
        {
            API.DrawRect(x, y, width, height, r, g, b, a);
        }

        private static void DrawText(string text, float x, float y, float scale, int[] color, bool isBold)
        {
            API.SetTextFont(isBold ? 1 : 0);
            API.SetTextProportional(true);
            API.SetTextScale(scale, scale);
            API.SetTextCentre(true);
            API.SetTextColour(color[0], color[1], color[2], color[3]);
            API.SetTextDropshadow(2, 0, 0, 0, 255);
            API.SetTextOutline();
            API.SetTextEntry("STRING");
            API.AddTextComponentString(text);
            API.DrawText(x, y);
        }

        private void NavigateUp()
        {
            if (!_isMenuOpen) return;
            _selectedIndex--;
            if (_selectedIndex < 0) _selectedIndex = _menuStack.Peek().Items.Count - 1;
            DrawMenu(_menuStack.Peek());
        }

        private void NavigateDown()
        {
            if (!_isMenuOpen) return;
            _selectedIndex++;
            if (_selectedIndex >= _menuStack.Peek().Items.Count) _selectedIndex = 0;
            DrawMenu(_menuStack.Peek());
        }

        private void SelectOption()
        {
            if (!_isMenuOpen) return;
            _menuStack.Peek().OnSelect(_selectedIndex);
            DrawMenu(_menuStack.Peek());
        }

        private void BackMenu()
        {
            if (!_isMenuOpen) return;

            if (_menuStack.Count > 1)
            {
                _menuStack.Pop();
                _selectedIndex = 0;
            }
            else
            {
                ToggleMenu();
            }

            DrawMenu(_menuStack.Peek());
        }
    }
}
