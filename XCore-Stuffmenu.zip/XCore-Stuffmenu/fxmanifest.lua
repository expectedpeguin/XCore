
fx_version 'bodacious'
games {'gta5'}

name 'XCore Stuffmenu'
description 'XCore Stuffmenu based on XCore functionality'
version 'v0.0.1'
author 'Goku'
url 'https://github.com/expectedpeguin/XCore/'

-- files {
--     'Client/Microsoft.Diagnostics.Tracing.EventSource.dll'
-- }

client_script 'Client/XCore.Menu-Client.net.dll'
-- server_script 'Server/XCore.Server.net.dll'